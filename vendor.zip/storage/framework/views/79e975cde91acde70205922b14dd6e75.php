<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div id="carouselExampleControls" class="carousel slide " data-bs-ride="carousel">
                <div class="carousel-inner ">
                  <div class="carousel-item active">
                    <img src="<?php echo e(asset('template/assets/img/4.jpg')); ?>" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img src="<?php echo e(asset('template/assets/img/2.jpg')); ?>" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img src="<?php echo e(asset('template/assets/img/3.jpg')); ?>" class="d-block w-100" alt="...">
                  </div>
                </div>

                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
  </div>
  <div class="pagetitle mt-3">
    <h1>Fotografer</h1>
</div>

  <div class="row m-0 row-cols-1 row-cols-md-3 g-4">
    <?php $__currentLoopData = $fotografers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotografer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card h-100">
                <img src="<?php echo e($fotografer->foto); ?>" class="card-img-top w-75 mx-auto mt-3 rounded-circle " alt="...">
                <div class="card-body pb-0">
                    <h5 class="card-title fw-bold pb-0 fs-5"><?php echo e($fotografer->nama); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($fotografer->provider->nama); ?></h6>
                    <p class="card-text mb-0"><?php echo e(Str::limit($fotografer->deskripsi, 75, '...')); ?></p>
                    <p class="card-text"><small class="text-muted"><a
                                href="/Fotografer/<?php echo e($fotografer->id); ?>">Detail</a></small></p>
                </div>
                <div class="card-footer">
                    <p class="card-text text-danger fw-bolder float-end">Rp. <?php echo e($fotografer->harga); ?>/hari</p>
                    <button type="button" class="btn btn-primary w-100"><i class="bi bi-cart-check m-2"></i><span>pesan
                            Sekarang</span></button>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="mt-3">
    <?php echo e($fotografers->links('vendor.pagination.bootstrap-5')); ?>

</div>


  <div class="pagetitle mt-3">
      <h1>Kamera</h1>
  </div>
  <div class="row m-0 row-cols-1 row-cols-md-3 g-4">
    <?php $__currentLoopData = $kameras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kamera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card h-100">
                <img src="<?php echo e($kamera->foto); ?>" class="card-img-top rounded w-100 mx-auto " alt="...">
                <div class="card-body pb-0">
                    <h5 class="card-title fw-bold pb-0 fs-5"><?php echo e($kamera->nama); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($kamera->provider->nama); ?></h6>
                    <p class="card-text mb-0"><?php echo e(Str::limit($kamera->spesifikasi, 75, '...')); ?></p>
                    <p class="card-text"><small class="text-muted"><a
                                href="/Kamera/<?php echo e($kamera->id); ?>">Detail</a></small>
                    </p>
                </div>
                <div class="card-footer">
                    <p class="card-text text-danger fw-bolder float-end">Rp. <?php echo e($kamera->harga); ?>/hari</p>
                    <button type="button" class="btn btn-primary w-100"><i class="bi bi-cart-check m-2"></i><span>pesan
                            Sekarang</span></button>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="mt-3">
    <?php echo e($kameras->links('vendor.pagination.bootstrap-5')); ?>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\jasfer\resources\views/beranda.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle mb-0">
        <h1><?php echo e($title); ?></h1>
    </div>
    <!-- End Page Title -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    
    <div class="row m-0 row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $fotografers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotografer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card h-100">
                    <img src="<?php echo e($fotografer->foto); ?>" class="card-img-top w-75 mx-auto mt-3 rounded-circle " alt="...">
                    <div class="card-body pb-0">
                        <h5 class="card-title fw-bold pb-0 fs-5"><?php echo e($fotografer->nama); ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted"><?php echo e($fotografer->provider->nama); ?></h6>
                        <p class="card-text mb-0"><?php echo e(Str::limit($fotografer->deskripsi, 75, '...')); ?></p>
                        <p class="card-text"><small class="text-muted"><a
                                    href="/Fotografer/<?php echo e($fotografer->id); ?>">Detail</a></small></p>
                    </div>
                    <div class="card-footer">
                        <p class="card-text text-danger fw-bolder float-end">Rp. <?php echo e($fotografer->harga); ?>/hari</p>
                        <button type="button" class="btn btn-primary w-100"><i class="bi bi-cart-check m-2"></i><span>pesan
                                Sekarang</span></button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-3">
        <?php echo e($fotografers->links('vendor.pagination.bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\jasfer\resources\views/fotografer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('cart'); ?>
    <li class="nav-item dropdown">
        <a class="nav-link nav-icon" href="" data-bs-toggle="dropdown">
            <i class="bi bi-cart-check"></i>
            <span class="badge bg-primary badge-number"><?php echo e(count($userCart)); ?></span>
        </a><!-- End Notification Icon -->
        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
                <?php echo e(count($userCart)); ?> barang di keranjang
            </li>
            <?php if(isset($userCart)): ?>
                <?php $__currentLoopData = $userCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li class="notification-item">
                        <div>
                            <h4><?php echo e($item->fotografer ? $item->fotografer->nama : $item->kamera->nama); ?>

                            </h4>
                            <p class="text-danger">Rp.
                                <?php echo e($item->fotografer ? $item->fotografer->harga : $item->kamera->harga); ?>/hari
                            </p>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            

            

            

        </ul><!-- End Notification Dropdown Items -->

    </li><!-- End Notification Nav -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\jasfer\resources\views/user/cart.blade.php ENDPATH**/ ?>